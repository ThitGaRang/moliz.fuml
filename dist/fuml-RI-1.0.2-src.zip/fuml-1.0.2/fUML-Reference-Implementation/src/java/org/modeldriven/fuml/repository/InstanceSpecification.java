package org.modeldriven.fuml.repository;

public interface InstanceSpecification extends NamedElement {

}
