package fUML.utility;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
public class MexSystem {
    static public void println(String message) {
        System.out.println(message);
    }

}
