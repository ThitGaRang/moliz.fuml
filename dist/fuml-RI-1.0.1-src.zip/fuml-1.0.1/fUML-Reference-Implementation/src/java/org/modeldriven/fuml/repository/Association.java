package org.modeldriven.fuml.repository;


public interface Association extends Classifier {

	public fUML.Syntax.Classes.Kernel.Association getDelegate();         
    
} // Association
