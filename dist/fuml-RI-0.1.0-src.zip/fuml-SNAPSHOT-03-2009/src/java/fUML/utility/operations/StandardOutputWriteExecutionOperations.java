package fUML.utility.operations;

import fUML.Library.ChannelImplementation.StandardOutputWriteExecution;

public class StandardOutputWriteExecutionOperations {
    static public void doBody(StandardOutputWriteExecution standardOutputWriteExecution,
            fUML.Semantics.CommonBehaviors.BasicBehaviors.ParameterValueList inputParameters,
            fUML.Semantics.CommonBehaviors.BasicBehaviors.ParameterValueList outputParameters) {
    }

    static public fUML.Semantics.Classes.Kernel.Value new_(
            StandardOutputWriteExecution standardOutputWriteExecution) {
        return null;
    }

}
