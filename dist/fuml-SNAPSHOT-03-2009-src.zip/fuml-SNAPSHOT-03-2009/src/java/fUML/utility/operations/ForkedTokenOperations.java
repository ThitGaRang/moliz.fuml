package fUML.utility.operations;

import fUML.Semantics.Activities.IntermediateActivities.ForkedToken;

public class ForkedTokenOperations {
    static public void Operation1(ForkedToken forkedToken) {
    }

}
