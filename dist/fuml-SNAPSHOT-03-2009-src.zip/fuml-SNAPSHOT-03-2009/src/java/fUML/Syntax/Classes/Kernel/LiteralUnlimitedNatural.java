/*
 * Copyright 2008 Lockheed Martin Corporation, except as stated in the file 
 * entitled Licensing-Information. Licensed under the Academic Free License 
 * version 3.0 (http://www.opensource.org/licenses/afl-3.0.php), except as stated 
 * in the file entitled Licensing-Information. 
 *
 * Contributors:
 *   MDS - initial API and implementation
 *
 */

package fUML.Syntax.Classes.Kernel;

import fUML.utility.MexSystem;
import fUML.Debug;
import UMLPrimitiveTypes.intList;

/**
 * <!-- begin-user-doc --> An implementation of the model object '
 * <em><b>fUML::Syntax::Classes::Kernel::LiteralUnlimitedNatural</b></em>'. <!--
 * end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 * <li>{@link LiteralUnlimitedNatural#setValue <em>setValue</em>}</li>
 * <li>{@link LiteralUnlimitedNatural#setValue <em>setValue</em>}</li>
 * <li>{@link LiteralUnlimitedNatural#value <em>value</em>}</li>
 * </ul>
 * </p>
 * 
 * @generated
 */

public class LiteralUnlimitedNatural extends fUML.Syntax.Classes.Kernel.LiteralSpecification {

    // Attributes
    public fUML.Syntax.Classes.Kernel.UnlimitedNatural value = new UnlimitedNatural(0);

    // Operations of the class
    /**
     * operation setValue <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     */

    public void setValue(fUML.Syntax.Classes.Kernel.UnlimitedNatural value) {
        this.value = value;

    }

    /**
     * operation setValue <!-- begin-user-doc --> <!-- end-user-doc -->
     * 
     * @generated
     */

    public void setValue(int value) {
        this.setValue(new UnlimitedNatural(value));

    }

} // LiteralUnlimitedNatural
