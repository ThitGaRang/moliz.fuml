
package org.modeldriven.fuml.common.uuid;

public class MalformedUUIDException extends RuntimeException {

    public MalformedUUIDException()
    {
        super();
    }

    public MalformedUUIDException(String string)
    {
        super(string);
    }
}
