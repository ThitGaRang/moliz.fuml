package org.modeldriven.fuml.repository.ext;




public class Stereotype extends fUML.Syntax.Classes.Kernel.Class_ {


} // Stereotype
