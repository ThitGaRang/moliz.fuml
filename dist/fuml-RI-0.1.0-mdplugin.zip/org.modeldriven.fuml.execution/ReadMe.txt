Foundational UML Reference Implementation
-----------------------------------------

This open source software is a reference implementation, consisting of software
and related files, for the OMG specification called the Semantics of a
Foundational Subset for Executable UML Models (fUML). The reference
implementation is intended to implement the execution semantics of UML activity
models, accepting an XMI file from a conformant UML model as its input and
providing an execution trace of the selected activity model(s) as its output.

The reference implementation was developed as part of a Lockheed Martin
Corporation funded project with Model Driven Solutions (a division of Data
Access Technologies) in 2008. The objectives for making this reference
implementation open source are to:

a) encourage tool vendors to implement this standard in their tools

b) provide a reference that can assist in evaluating vendor implementations
conformance with the specification

c) encourage evolution of the reference implementation to support further
enhancements to its functionality such as a model debugger, or animation of the
execution trace

d) support evaluation and evolution of the the specification to support UML
execution semantics and the execution semantics of its profiles suchas SysML.

Licensing
---------

For licensing information, please see the file Licensing-Information.txt and the
associated files Common-Public-License-1.0.txt and Apache-License-2.0.txt.

MagicDraw Plugin
----------------

The MagicDraw Plugin requires MagicDraw 16.0.

To install the plugin, unzip the distribution file directly into the
plugins subdirectory of your MagicDraw installation directory and restart
MagicDraw.

To use the MagicDraw Plugin:

1. Create a model with one or more activities. Note: The model should not
contain elements outside of the fUML subset that cannot be loaded by the
reference implementation.

2. Save the model as an mdxml file. Note: The reference implementation cannot
read an mdzip file. The model must be saved before it can be executed.

3. Select an activity to be executed. The activity must be at the top level in
the model (i.e., directly under "Data").

4. To execute the activity, do one of the following:

   a) Right click on the activity in the tree browser and select Execute. 
   b) Select the activity in the tree browser and press Alt-Shift-E. 
   c) Open the activity and click the Execute icon on the toolbar.
